# JE Song Bot
## A telegram bot that can download songs
<p align="center">
  <img src="https://telegra.ph/file/172120c93b52738be277b.jpg">
</p>

Reach me on Telegram [Song Bot 🎵](https://t.me/jesongbot)

## How To Host

The easiest way to deploy this Song Bot
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/ImJanindu/JESongBot"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blueviolet?style=for-the-badge&logo=heroku" width="210" height="34.45"/></a></p>

## Credits

- [Pyrogram](https://github.com/pyrogram)
- Mr Dark Prince
